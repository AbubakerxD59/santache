<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{
    public $data = [];
    public $response = [];

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->helper(['url', 'language', 'timezone_helper']);
        $this->load->model(['address_model', 'category_model', 'cart_model', 'faq_model', 'brand_model', 'chat_model', 'flash_sale_model']);
        $this->load->library(['pagination', 'ion_auth', 'form_validation']);
        $this->data['is_logged_in'] = ($this->ion_auth->logged_in()) ? 1 : 0;
        $this->data['user'] = ($this->ion_auth->logged_in()) ? $this->ion_auth->user()->row() : array();
        $this->data['settings'] = get_settings('system_settings', true);
        $this->data['web_settings'] = get_settings('web_settings', true);
        $this->response['csrfName'] = $this->security->get_csrf_token_name();
        $this->response['csrfHash'] = $this->security->get_csrf_hash();

        if ($this->ion_auth->logged_in()) {
            $user = $this->ion_auth->user()->row();

            if (!$user->active) {
                $this->ion_auth->logout();

                $this->session->set_flashdata('authorize_flag', "Your account is deactivated. Please contact the administrator.");
                redirect('home');
            }
        }
    }

    public function index()
    {
        if ((isset($this->data['settings']['is_web_under_maintenance']) && $this->data['settings']['is_web_under_maintenance'] == 1)) {
            redirect(base_url("maintenance"));
        }
        $this->data['main_page'] = 'home';
        $this->data['title'] = 'Home | ' . $this->data['web_settings']['site_title'];
        $this->data['keywords'] = 'Home, ' . $this->data['web_settings']['meta_keywords'];
        $this->data['description'] = 'Home | ' . $this->data['web_settings']['meta_description'];

        $limit = 12;
        $offset = 0;
        $sort = 'row_order';
        $order = 'ASC';
        $has_child_or_item = 'false';
        $filters = [];
        /* Fetching Categories Sections */
        $categories = $this->category_model->get_categories('', $limit, $offset, $sort, $order, 'false');
        $brands = $this->brand_model->get_brands('', $limit, $offset, $sort, $order, 'false');

        /* Fetching Featured Sections */

        $sections = $this->db->limit($limit, $offset)->order_by('row_order')->get('sections')->result_array();
        $user_id = NULL;
        if ($this->data['is_logged_in']) {
            $user_id = $this->data['user']->id;
        }
        $filters['show_only_active_products'] = true;
        if (!empty($sections)) {
            for ($i = 0; $i < count($sections); $i++) {
                $product_ids = explode(',', (string) $sections[$i]['product_ids']);
                $product_ids = explode(',', (string) $sections[$i]['product_ids']);
                $product_ids = array_filter($product_ids);
                $product_categories = (isset($sections[$i]['categories']) && !empty($sections[$i]['categories']) && $sections[$i]['categories'] != NULL) ? explode(',', $sections[$i]['categories'] ?? '') : null;
                if (isset($sections[$i]['product_type']) && !empty($sections[$i]['product_type'])) {
                    $filters['product_type'] = (isset($sections[$i]['product_type'])) ? $sections[$i]['product_type'] : null;
                }

                $theme = fetch_details('themes', ['status' => 1], 'name');
                if (isset($theme[0]['name']) && strtolower($theme[0]['name']) == 'modern') {
                    if ($sections[$i]['style'] == "default") {
                        $limit = 10;
                    } elseif ($sections[$i]['style'] == "style_1" || $sections[$i]['style'] == "style_2") {
                        $limit = 4;
                    } elseif ($sections[$i]['style'] == "style_3" || $sections[$i]['style'] == "style_4") {
                        $limit = 7;
                    } else {
                        $limit = null;
                    }
                } else {
                    if ($sections[$i]['style'] == "default") {
                        $limit = 10;
                    } elseif ($sections[$i]['style'] == "style_1" || $sections[$i]['style'] == "style_2") {
                        $limit = 7;
                    } elseif ($sections[$i]['style'] == "style_3" || $sections[$i]['style'] == "style_4") {
                        $limit = 5;
                    } else {
                        $limit = null;
                    }
                }

                $products = fetch_product($user_id, (isset($filters)) ? $filters : null, (isset($product_ids)) ? $product_ids : null, $product_categories, $limit, null, null, null);

                $sections[$i]['title'] = output_escaping($sections[$i]['title']);
                $sections[$i]['slug'] = url_title($sections[$i]['title'], 'dash', true);
                $sections[$i]['short_description'] = output_escaping($sections[$i]['short_description']);
                $sections[$i]['filters'] = (isset($products['filters'])) ? $products['filters'] : [];
                $sections[$i]['product_details'] = $products['product'];
                unset($sections[$i]['product_details'][0]['total']);
                $sections[$i]['product_details'] = $products['product'];
                unset($product_details);
            }
        }
        // fetch offers data
        $offer_slider = fetch_details('offer_sliders', '', '');
        // fetch flash_sale data
        $flash_sale = fetch_details('flash_sale', where_in_key: 'status', where_in_value: [1, 2]);


        if (!empty($flash_sale)) {
            for ($i = 0; $i < count($flash_sale); $i++) {
                $product_ids = explode(',', $flash_sale[$i]['product_ids'] ?? '');
                $product_ids = array_filter($product_ids);

                $sale_products = fetch_product(null, null, (isset($product_ids)) ? $product_ids : null, null, null, null, null, null);
                $flash_sale[$i]['product_details'] = $sale_products['product'];
            }
        }
        $this->data['sections'] = $sections;
        $this->data['flash_sale'] = $flash_sale;
        $this->data['offer_slider'] = $offer_slider;
        $this->data['categories'] = $categories;
        $this->data['brands'] = $brands;
        $this->data['username'] = $this->session->userdata('username');
        $this->data['sliders'] = get_sliders();
        $this->load->view('front-end/' . THEME . '/template', $this->data);
    }

    public function brands()
    {
        $web_doctor_brown = get_settings('web_doctor_brown', true);
        $system_settings = get_settings('system_settings', true);
        if ((isset($system_settings['is_web_under_maintenance']) && $system_settings['is_web_under_maintenance'] == 1)) {
            /* redirect him to the page where he can enter the purchase code */
            redirect(base_url("maintenance"));
        }

        $offset = 0;
        $sort = 'row_order';
        $order = 'ASC';
        $brands = $this->brand_model->get_brands('', $limit = NULL, $offset, $sort, $order, 'false');

        $limit = ($this->input->get('per-page')) ? $this->input->get('per-page', true) : 16;

        $total_rows = count($brands);


        $config['base_url'] = base_url('home/brands/');
        $config['total_rows'] = $total_rows;
        $config['per_page'] = $limit;
        $config['use_page_numbers'] = TRUE;
        $config['uri_segment'] = 3;
        $config['num_links'] = 3;
        $config['use_page_numbers'] = TRUE;
        $config['reuse_query_string'] = TRUE;
        $config['page_query_string'] = FALSE;

        $config['attributes'] = array('class' => 'page-link');
        $config['full_tag_open'] = '<ul class="pagination justify-content-center">';
        $config['full_tag_close'] = '</ul>';

        $config['first_tag_open'] = '<li class="page-item">';
        $config['first_link'] = 'First';
        $config['first_tag_close'] = '</li>';

        $config['last_tag_open'] = '<li class="page-item">';
        $config['last_link'] = 'Last';
        $config['last_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link">';
        $config['cur_tag_close'] = '</a></li>';

        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';
        $page_no = (empty($this->uri->segment(3))) ? 1 : $this->uri->segment(3);
        if (!is_numeric($page_no)) {
            redirect(base_url('brands'));
        }
        $offset = ($page_no - 1) * $limit;
        $this->pagination->initialize($config);
        $this->data['links'] = $this->pagination->create_links();


        $this->data['main_page'] = 'Brands';
        $this->data['title'] = 'Brands | ' . $this->data['web_settings']['site_title'];
        $this->data['keywords'] = 'Brands, ' . $this->data['web_settings']['meta_keywords'];
        $this->data['description'] = 'Brands | ' . $this->data['web_settings']['meta_description'];
        $this->data['brands'] = $brands;

        $this->load->view('front-end/' . THEME . '/template', $this->data);
    }

    public function _render_page($view, $data = NULL, $returnhtml = FALSE) //I think this makes more sense
    {

        $viewdata = (empty($data)) ? $this->data : $data;

        $view_html = $this->load->view($view, $viewdata, $returnhtml);

        // This will return html on 3rd argument being true
        if ($returnhtml) {
            return $view_html;
        }
    }

    public function error_404()
    {
        $this->data['main_page'] = 'error_404';
        $this->data['title'] = 'Product cart | ' . $this->data['web_settings']['site_title'];
        $this->data['keywords'] = 'Product cart, ' . $this->data['web_settings']['meta_keywords'];
        $this->data['description'] = 'Product cart | ' . $this->data['web_settings']['meta_description'];
        $this->load->view('front-end/' . THEME . '/template', $this->data);
    }


    public function maintenance_mode()
    {
        $settings = get_settings('system_settings', true);
        // If maintenance mode is OFF, redirect to home
        if (!isset($settings['is_web_under_maintenance']) || $settings['is_web_under_maintenance'] != 1) {
            redirect(base_url('home'));
        }

        $this->data['main_page'] = 'maintenance_mode';
        $this->data['title'] = 'Product cart | ' . $this->data['web_settings']['site_title'];
        $this->data['keywords'] = 'Product cart, ' . $this->data['web_settings']['meta_keywords'];
        $this->data['description'] = 'Product cart | ' . $this->data['web_settings']['meta_description'];
        $this->load->view('front-end/' . THEME . '/template', $this->data);
    }

    public function categories()
    {
        $web_doctor_brown = get_settings('web_doctor_brown', true);

        $limit = 50;
        $offset = 0;
        $sort = 'row_order';
        $order = 'ASC';
        $has_child_or_item = 'false';
        $this->data['main_page'] = 'categories';
        $this->data['title'] = 'Categories | ' . $this->data['web_settings']['site_title'];
        $this->data['keywords'] = 'Categories, ' . $this->data['web_settings']['meta_keywords'];
        $this->data['description'] = 'Categories | ' . $this->data['web_settings']['meta_description'];
        $this->data['categories'] = $this->category_model->get_categories('', $limit, $offset, $sort, $order, 'false');
        $this->load->view('front-end/' . THEME . '/template', $this->data);
    }

    public function get_products()
    {

        $this->form_validation->set_data($this->input->get());
        $this->form_validation->set_rules('id', 'Product ID', 'trim|numeric|xss_clean');
        $this->form_validation->set_rules('search', 'Search', 'trim|xss_clean');
        $this->form_validation->set_rules('category_id', 'Category id', 'trim|numeric|xss_clean');
        $this->form_validation->set_rules('sort', 'sort', 'trim|xss_clean');
        $this->form_validation->set_rules('limit', 'limit', 'trim|numeric|xss_clean');
        $this->form_validation->set_rules('offset', 'offset', 'trim|numeric|xss_clean');
        $this->form_validation->set_rules('order', 'order', 'trim|xss_clean|alpha');

        if (!$this->form_validation->run()) {
            $this->response['error'] = true;
            $this->response['message'] = strip_tags(validation_errors());
            $this->response['data'] = array();
        } else {

            $limit = (isset($_GET['limit'])) ? $this->input->get('limit', true) : 25;
            if (isset($_GET['page']) && !empty($_GET['page'])) {
                $offset = ($_GET['page'] - 1) * $limit;
            } else {
                $offset = (isset($_GET['offset'])) ? $this->input->get('offset', true) : 0;
            }
            $order = (isset($_GET['order']) && !empty(trim($_GET['order']))) ? $this->input->get('order', true) : 'DESC';
            $sort = (isset($_GET['sort']) && !empty(trim($_GET['sort']))) ? $this->input->get('sort', true) : 'p.id';
            $filters['search'] = (isset($_GET['search'])) ? $this->input->get('search', true) : null;
            $filters['attribute_value_ids'] = (isset($_GET['attribute_value_ids'])) ? $_GET['attribute_value_ids'] : null;
            $category_id = (isset($_GET['category_id'])) ? $this->input->get('category_id', true) : null;
            $product_id = (isset($_GET['id'])) ? $_GET['id'] : null;
            $user_id = (isset($_GET['user_id'])) ? $_GET['user_id'] : null;

            $products = fetch_product($user_id, (isset($filters)) ? $filters : null, $product_id, $category_id, $limit, $offset, $sort, $order);
            $first_search_option[0] = array(
                'id' => 0,
                'image_sm' => base_url(get_settings('favicon')),
                'name' => 'Search Result for ' . html_escape($_GET['search']),
                'category_name' => 'all categories',
                'link' => base_url('products/search?q=' . html_escape($_GET['search'])),
            );
            if (!empty($products['product'])) {
                $products['product'] = array_map(function ($d) {
                    $d['link'] = base_url('products/details/' . $d['slug']);
                    return $d;
                }, $products['product']);
                $this->response['error'] = false;
                $this->response['message'] = "Products retrieved successfully !";
                $this->response['filters'] = (isset($products['filters']) && !empty($products['filters'])) ? $products['filters'] : [];
                $this->response['total'] = (isset($products['total'])) ? strval($products['total']) : '';
                $this->response['offset'] = (isset($_GET['offset']) && !empty($_GET['offset'])) ? $_GET['offset'] : '0';
                if (isset($_GET['page']) && !empty($_GET['page'])) {
                    $products['product'] = $products['product'];
                } else {
                    $products['product'] = array_merge($first_search_option, $products['product']);
                }
                $this->response['data'] = $products['product'];
            } else {
                $this->response['error'] = true;
                $this->response['message'] = "Products Not Found !";
                $this->response['data'] = $first_search_option;
            }
        }
        print_r(json_encode($this->response));
    }

    public function address_list()
    {
        if ($this->ion_auth->logged_in() && $this->ion_auth->is_admin()) {
            return $this->address_model->get_address_list();
        } else {
            redirect('admin/login', 'refresh');
        }
    }

    public function checkout()
    {
        $this->data['main_page'] = 'checkout';
        $this->data['title'] = 'Checkout | ' . $this->data['web_settings']['site_title'];
        $this->data['keywords'] = 'Checkout, ' . $this->data['web_settings']['meta_keywords'];
        $this->data['description'] = 'Checkout | ' . $this->data['web_settings']['meta_description'];
        $this->load->view('front-end/' . THEME . '/template', $this->data);
    }

    public function terms_and_conditions()
    {
        $this->data['main_page'] = 'terms-and-conditions';
        $this->data['title'] = 'Terms & Conditions | ' . $this->data['web_settings']['site_title'];
        $this->data['keywords'] = 'Terms & Conditions, ' . $this->data['web_settings']['meta_keywords'];
        $this->data['description'] = 'Terms & Conditions | ' . $this->data['web_settings']['meta_description'];
        $this->data['meta_description'] = 'Terms & Conditions | ' . $this->data['web_settings']['site_title'];
        $this->data['terms_and_conditions'] = get_settings('terms_conditions');
        $this->load->view('front-end/' . THEME . '/template', $this->data);
    }

    public function privacy_policy()
    {
        $this->data['main_page'] = 'privacy-policy';
        $this->data['title'] = 'Privacy Policy | ' . $this->data['web_settings']['site_title'];
        $this->data['keywords'] = 'Privacy Policy, ' . $this->data['web_settings']['meta_keywords'];
        $this->data['description'] = 'Privacy Policy | ' . $this->data['web_settings']['meta_description'];
        $this->data['meta_description'] = 'Privacy Policy | ' . $this->data['web_settings']['site_title'];
        $this->data['privacy_policy'] = get_settings('privacy_policy');
        $this->load->view('front-end/' . THEME . '/template', $this->data);
    }
    public function about_us()
    {
        $this->data['main_page'] = 'about-us';
        $this->data['title'] = 'About US | ' . $this->data['web_settings']['site_title'];
        $this->data['keywords'] = 'About US, ' . $this->data['web_settings']['meta_keywords'];
        $this->data['description'] = 'About US | ' . $this->data['web_settings']['meta_description'];
        $this->data['meta_description'] = 'About US | ' . $this->data['web_settings']['site_title'];
        $this->data['about_us'] = get_settings('about_us');
        $this->load->view('front-end/' . THEME . '/template', $this->data);
    }

    public function contact_us()
    {
        $this->data['main_page'] = 'contact-us';
        $this->data['title'] = 'Contact US | ' . $this->data['web_settings']['site_title'];
        $this->data['keywords'] = 'Contact US, ' . $this->data['web_settings']['meta_keywords'];
        $this->data['description'] = 'Contact US | ' . $this->data['web_settings']['meta_description'];
        $this->data['meta_description'] = 'Contact US | ' . $this->data['web_settings']['site_title'];
        $this->data['contact_us'] = get_settings('contact_us');
        $this->data['web_settings'] = get_settings('web_settings', true);
        $this->load->view('front-end/' . THEME . '/template', $this->data);
    }

    public function system_contact_us()
    {
        $this->data['main_page'] = 'system-contact-us';
        $this->data['title'] = 'Contact US | ' . $this->data['web_settings']['site_title'];
        $this->data['keywords'] = 'Contact US, ' . $this->data['web_settings']['meta_keywords'];
        $this->data['description'] = 'Contact US | ' . $this->data['web_settings']['meta_description'];
        $this->data['meta_description'] = 'Contact US | ' . $this->data['web_settings']['site_title'];
        $this->data['contact_us'] = get_settings('contact_us');
        $this->data['web_settings'] = get_settings('web_settings', true);
        $this->load->view('front-end/' . THEME . '/template', $this->data);
    }

    public function faq()
    {
        $this->data['main_page'] = 'faq';
        $this->data['title'] = 'FAQ | ' . $this->data['web_settings']['site_title'];
        $this->data['keywords'] = 'FAQ, ' . $this->data['web_settings']['meta_keywords'];
        $this->data['description'] = 'FAQ | ' . $this->data['web_settings']['meta_description'];
        $this->data['meta_description'] = 'FAQ | ' . $this->data['web_settings']['site_title'];
        $this->data['faq'] = $this->faq_model->get_faqs(null, null, null, null);
        $this->load->view('front-end/' . THEME . '/template', $this->data);
    }


    /**
     * Log the user in
     */
    public function login()
    {

        $regex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';
        $this->data['title'] = $this->lang->line('login_heading');

        if (!empty($_POST['mobile'])) {
            $_POST['identity'] = $_POST['mobile'];
        } elseif (!empty($_POST['email'])) {
            $_POST['identity'] = $_POST['email'];
        }
        // Keep existing $_POST['identity'] for social logins (google/facebook) that send identity directly

        $identity_column = $this->config->item('identity', 'ion_auth');


        // validate form input
        if (preg_match($regex, $_POST['identity'])) {
            $this->form_validation->set_rules('identity', ucfirst($identity_column), 'trim|required|valid_email|xss_clean');
        } else {
            $this->form_validation->set_rules('identity', ucfirst($identity_column), 'required|numeric|xss_clean');
        }

        $this->form_validation->set_rules('password', str_replace(':', '', $this->lang->line('login_password_label')), 'required|xss_clean');

        if ($this->form_validation->run() === TRUE) {
            $tables = $this->config->item('tables', 'ion_auth');
            $identity = $this->input->post('identity', true);

            // Determine if login is by email or mobile and set identity column FIRST
            $is_email_login = false;
            if (filter_var($identity, FILTER_VALIDATE_EMAIL) || (isset($_POST['type']) && $_POST['type'] != 'phone')) {
                // Email login
                $is_email_login = true;
                $this->ion_auth->ion_auth_model->identity_column = 'email';
                $res = $this->db->select('id')->where('email', $identity)->get($tables['login_users'])->result_array();
                $user_data = fetch_details('users', ['email' => $identity]);
            } else {
                // Phone/Mobile login
                $res = $this->db->select('id')->where($identity_column, $identity)->get($tables['login_users'])->result_array();
                $user_data = fetch_details('users', ['mobile' => $identity]);
            }

            if (isset($user_data[0]['active']) && !empty($user_data) && $user_data[0]['active'] == 0) {
                $this->response['error'] = true;
                $this->response['message'] = 'Account is Deactivated';
                echo json_encode($this->response);
                return false;
            }

            if (!empty($res)) {
                // check to see if the user is logging in
                // check for "remember me"
                $remember = (bool) $this->input->post('remember');

                $login_type = $this->input->post('type', true) ? $this->input->post('type', true) : '';
                if ($this->ion_auth->login($this->input->post('identity'), $this->input->post('password'), $remember, $login_type)) {

                    //if the login is successful
                    if (!$this->input->is_ajax_request()) {
                        redirect('admin/home', 'refresh');
                    }
                    $this->response['error'] = false;
                    $this->response['message'] = $this->ion_auth->messages();
                    echo json_encode($this->response);
                } else {
                    if (in_array($login_type, ['google', 'facebook'], true) && $is_email_login) {
                        $social_password = $this->input->post('password', true);
                        $social_identity = $this->input->post('identity', true);
                        if (!empty($social_password) && !empty($social_identity)) {
                            $new_hash = $this->ion_auth->hash_password($social_password);
                            if (!empty($new_hash)) {
                                $this->db->set('password', $new_hash)
                                    ->where('email', $social_identity)
                                    ->where('type', $login_type)
                                    ->update($tables['login_users']);

                                if ($this->ion_auth->login($social_identity, $social_password, $remember, $login_type)) {
                                    $this->response['error'] = false;
                                    $this->response['message'] = $this->ion_auth->messages();
                                    echo json_encode($this->response);
                                    return;
                                }
                            }
                        }
                    }

                    // if the login was un-successful
                    $this->response['error'] = true;
                    // Dynamic error message based on login type
                    if ($is_email_login) {
                        $this->response['message'] = 'Your email or password is incorrect';
                    } else {
                        $this->response['message'] = 'Your mobile or password is incorrect';
                    }
                    echo json_encode($this->response);
                }
            } else {
                $this->response['error'] = true;
                $this->response['message'] = '<div>Incorrect Login</div>';
                echo json_encode($this->response);
            }
        } else {


            // the user is not logging in so display the login page
            if (validation_errors()) {
                $this->response['error'] = true;
                $this->response['message'] = validation_errors();
                echo json_encode($this->response);
                return false;
                exit();
            }
            if ($this->session->flashdata('message')) {
                $this->response['error'] = false;
                $this->response['message'] = $this->session->flashdata('message');
                echo json_encode($this->response);
                return false;
                exit();
            }

            // set the flash data error message if there is one
            $this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

            $this->data['identity'] = [
                'name' => 'identity',
                'id' => 'identity',
                'type' => 'text',
                'value' => $this->form_validation->set_value('identity'),
            ];

            $this->data['password'] = [
                'name' => 'password',
                'id' => 'password',
                'type' => 'password',
            ];
        }
    }

    public function lang($lang_name = '')
    {
        if (empty($lang_name)) {
            redirect(base_url());
        }

        $language = get_languages(null, $lang_name);
        if (empty($language)) {
            redirect(base_url());
        }
        $this->lang->load('web_labels_lang', $lang_name);
        $cookie = array(
            'name' => 'language',
            'value' => $lang_name,
            'expire' => time() + 1000
        );
        $this->input->set_cookie($cookie);
        if (isset($_SERVER['HTTP_REFERER'])) {
            redirect($_SERVER['HTTP_REFERER']);
        } else {
            redirect(base_url());
        }
    }

    public function reset_password()
    {
        /* Parameters to be passed
            mobile: 7894561235 (optional)
            email: user@example.com (optional, used if mobile is empty)
            new_password: pass@123
            otp: 123456 (required for mobile-based reset if SMS authentication is enabled)
        */
        // Validate mobile if provided
        if (!empty($_POST['mobile'])) {
            $this->form_validation->set_rules('mobile', 'Mobile No', 'trim|numeric|required|xss_clean|max_length[16]');
        } else {
            // Validate email if mobile is empty
            $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|xss_clean');
        }
        $this->form_validation->set_rules('new_password', 'New Password', 'trim|required|xss_clean');

        if (!$this->form_validation->run()) {
            $this->response['error'] = true;
            $this->response['message'] = strip_tags(validation_errors());
            print_r(json_encode($this->response));
            return false;
        }

        $identity_column = $this->config->item('identity', 'ion_auth');
        $search_criteria = !empty($_POST['mobile']) ? ['mobile' => $_POST['mobile']] : ['email' => $_POST['email']];
        $res = fetch_details('users', $search_criteria);

        if (!empty($res)) {
            if (!empty($_POST['mobile'])) {
                // Mobile-based reset
                $otp_from_db = fetch_details('otps', ['mobile' => $_POST['mobile']]);
                $current_otp = $_POST['otp'] ?? '';
                $sms_settings = get_settings('authentication_settings', true);

                if ($sms_settings['authentication_method'] == "sms") {
                    if (!empty($otp_from_db) && $current_otp == $otp_from_db[0]['otp']) {
                        $identity = ($identity_column == 'email') ? $res[0]['email'] : $res[0]['mobile'];
                        if (!$this->ion_auth->reset_password($identity, $_POST['new_password'])) {
                            $this->response['error'] = true;
                            $this->response['message'] = $this->ion_auth->messages();
                            $this->response['data'] = array();
                            echo json_encode($this->response);
                            return false;
                        } else {
                            $this->response['error'] = false;
                            $this->response['message'] = 'Reset Password Successfully 1';
                            $this->response['data'] = array();
                            echo json_encode($this->response);
                            return false;
                        }
                    } else {
                        $this->response['error'] = true;
                        $this->response['message'] = 'Invalid OTP. Please try again!';
                        $this->response['data'] = array();
                        echo json_encode($this->response);
                        return false;
                    }
                } else {
                    $identity = ($identity_column == 'email') ? $res[0]['email'] : $res[0]['mobile'];
                    if (!$this->ion_auth->reset_password($identity, $_POST['new_password'])) {
                        $this->response['error'] = true;
                        $this->response['message'] = $this->ion_auth->messages();
                        $this->response['data'] = array();
                        echo json_encode($this->response);
                        return false;
                    } else {
                        $this->response['error'] = false;
                        $this->response['message'] = 'Reset Password Successfully 2';
                        $this->response['data'] = array();
                        echo json_encode($this->response);
                        return false;
                    }
                }
            } else {
                $email = $_POST['email'];
                $new_password = $_POST['new_password'];

                $hashed_password = $this->ion_auth->hash_password($new_password);

                $identity = $res[0]['email'];

                if ($this->ion_auth->reset_password($identity, $new_password)) {
                    $this->response['error'] = false;
                    $this->response['message'] = 'Password reset successfully!';
                    $this->response['data'] = array();
                    echo json_encode($this->response);
                    return false;
                } else {
                    $update_data = array(
                        'password' => $hashed_password,
                        'remember_code' => null,
                        'forgotten_password_code' => null,
                        'forgotten_password_time' => null
                    );

                    $updated = $this->db->where('email', $email)->update('users', $update_data);

                    if ($updated) {
                        $this->response['error'] = false;
                        $this->response['message'] = 'Password reset successfully!';
                        $this->response['data'] = array();
                        echo json_encode($this->response);
                        return false;
                    } else {
                        $this->response['error'] = true;
                        $this->response['message'] = 'Failed to update password in database. Please try again.';
                        $this->response['data'] = array();
                        echo json_encode($this->response);
                        return false;
                    }
                }
            }
        } else {
            $this->response['error'] = true;
            $this->response['message'] = 'User does not exist!';
            $this->response['data'] = array();
            echo json_encode($this->response);
            return false;
        }
    }

    public function send_contact_us_email()
    {
        $this->form_validation->set_rules('username', 'Name', 'trim|required|xss_clean');
        // $this->form_validation->set_rules('mobile', 'Mobile Number', 'trim|required|xss_clean');
        $this->form_validation->set_rules('message', 'Message', 'trim|required|xss_clean');


        $this->form_validation->set_error_delimiters('', '<br>');

        if (!$this->form_validation->run()) {
            $this->response['error'] = true;
            $this->response['message'] = validation_errors();
            $this->response['csrfName'] = $this->security->get_csrf_token_name();
            $this->response['csrfHash'] = $this->security->get_csrf_hash();
            echo json_encode($this->response);
            return false;
        }

        $username = $this->input->post('username', true);
        // $mobile = $this->input->post('mobile', true);
        $message = $this->input->post('message', true);

        $web_settings = get_settings('web_settings', true);
        $to = $web_settings['support_email'];

        $email_message =
            "Name : " . $username . "<br>" .
            // "Mobile : " . $mobile . "<br>" .
            "Message : " . $message . "<br>";

        $mail = send_mail($to, 'Contact Us', $email_message);

        if ($mail['error'] == true) {
            $this->response['error'] = true;
            $this->response['message'] = 'Cannot send mail. Please try again later.';
        } else {
            $this->response['error'] = false;
            $this->response['message'] = 'Mail sent successfully. We will get back to you soon.';
        }

        $this->response['csrfName'] = $this->security->get_csrf_token_name();
        $this->response['csrfHash'] = $this->security->get_csrf_hash();
        echo json_encode($this->response);
        return false;
    }



    public function shipping_policy()
    {
        $this->data['main_page'] = 'shipping-policy';
        $this->data['title'] = 'Shipping Policy | ' . $this->data['web_settings']['site_title'];
        $this->data['keywords'] = 'Shipping Policy, ' . $this->data['web_settings']['meta_keywords'];
        $this->data['description'] = 'Shipping Policy | ' . $this->data['web_settings']['meta_description'];
        $this->data['meta_description'] = 'Shipping Policy | ' . $this->data['web_settings']['site_title'];
        $this->data['shipping_policy'] = get_settings('shipping_policy');
        $this->load->view('front-end/' . THEME . '/template', $this->data);
    }
    public function return_policy()
    {
        $this->data['main_page'] = 'return-policy';
        $this->data['title'] = 'Return Policy | ' . $this->data['web_settings']['site_title'];
        $this->data['keywords'] = 'Return Policy, ' . $this->data['web_settings']['meta_keywords'];
        $this->data['description'] = 'Return Policy | ' . $this->data['web_settings']['meta_description'];
        $this->data['meta_description'] = 'Return Policy | ' . $this->data['web_settings']['site_title'];
        $this->data['return_policy'] = get_settings('return_policy');
        $this->load->view('front-end/' . THEME . '/template', $this->data);
    }

    public function get_product_faqs()
    {
        $filters['search'] = (isset($_GET['search'])) ? $_GET['search'] : null;
        $first_search_option[0] = array(
            'id' => 0,
            'image_sm' => base_url(get_settings('favicon')),
            'name' => 'Search Result for ' . $_GET['search'],
            'category_name' => 'all categories',
            'link' => base_url('products/search?q=' . $_GET['search']),
        );
    }

    public function get_csrf_token()
    {
        return print_r($this->security->get_csrf_hash());
    }
    public function verifyUser()
    {
        $this->form_validation->set_data($this->input->get());
        $this->form_validation->set_rules('email', 'Mail', 'trim|required|xss_clean|valid_email');
        if (!$this->form_validation->run()) {
            $this->response['error'] = true;
            $this->response['message'] = strip_tags(validation_errors());
            $this->response['csrfName'] = $this->security->get_csrf_token_name();
            $this->response['csrfHash'] = $this->security->get_csrf_hash();
            $this->response['data'] = array();
            print_r(json_encode($this->response));
        } else {
            $user_data = fetch_details('users', ['email' => $_POST['email'], 'type' => $_POST['type']]);
            if (!empty($user_data)) {
                $this->response['error'] = false;
                $this->response['message'] = 'data retrived';
                $this->response['csrfName'] = $this->security->get_csrf_token_name();
                $this->response['csrfHash'] = $this->security->get_csrf_hash();
                $this->response['data'] = $user_data[0];
                print_r(json_encode($this->response));
            } else {
                $this->response['error'] = true;
                $this->response['message'] = 'data not retrived';
                $this->response['csrfName'] = $this->security->get_csrf_token_name();
                $this->response['csrfHash'] = $this->security->get_csrf_hash();
                $this->response['data'] = $user_data;
                print_r(json_encode($this->response));
            }
        }
    }

    public function send_order_email($order_id = '')
    {
        if ($order_id != '') {
            $this->load->model('Order_model');
            $this->Order_model->send_order_notifications($order_id);
        }
    }
}
