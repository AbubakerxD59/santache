<div class="content-wrapper">
    <section class="content-header mt-4">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-8">
                    <h4>Authentication Mode</h4>
                </div>
                <div class="col-sm-4 d-flex justify-content-end">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url('admin/home') ?>">Home</a>
                        </li>
                        <li class="breadcrumb-item active">Authentication Mode</li>
                    </ol>
                </div>
            </div>
        </div>
        
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-info">
                        <form class="form-horizontal form-submit-event" action="<?= base_url('admin/Authentication_settings/update_authentication_settings'); ?>" method="POST" id="payment_setting_form" enctype="multipart/form-data">
                            <div class="card-body">

                                <input type="hidden" id="auth_setting" name="firebase_config" required="" value='<?= json_encode($authentication_config) ?>' aria-required="true">

                                <div class="">
                                    <div class="form-group d-flex gap-5">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="authentication_method" value="firebase" id="firebaseRadio" <?= (@$authentication_config['authentication_method']) == 'firebase' ? 'checked' : '' ?>>
                                            <label class="" for="firebaseRadio">
                                                Firebase Authentication
                                            </label>
                                        </div>
                                        <div class="form-check ml-5">
                                            <input class="form-check-input" type="radio" name="authentication_method" value="sms" id="smsRadio" <?= (@$authentication_config['authentication_method']) == 'sms' ? 'checked' : '' ?>>
                                            <label class="" for="smsRadio">
                                                Custom SMS Gateway OTP based
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex mt-3">
                                    <div class="firebase_config d-none">
                                        <a href="<?= base_url('admin/web-setting/firebase') ?>">
                                            <p class="text-danger">Please config firebase config here *</p>
                                        </a>
                                    </div>
                                    <div class="sms_gateway d-none">
                                        <a href="<?= base_url('admin/sms-gateway-settings') ?>">
                                            <p class="text-danger">Please config SMS gateway config here * </p>
                                        </a>
                                    </div>
                                </div>
                                <div class="form-group mt-3">
                                    <button type="reset" class="btn btn-warning">Reset</button>
                                    <button type="submit" class="btn btn-success" id="submit_btn">Update Authentication Settings</button>
                                </div>


                            </div>
                        </form>
                    </div>
                    <!--/.card-->
                </div>
                <!--/.col-md-12-->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>