<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Main content -->
    <section class="content-header mt-4">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-md-8">
                    <h4>Notification</h4>
                </div>
                <div class="col-md-4 d-flex justify-content-end">
                    <ol class="breadcrumb float-right">
                        <li class="breadcrumb-item"><a href="<?= base_url('admin/home') ?>">Home</a></li>
                        <li class="breadcrumb-item active">Send Notification</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-info">
                        <!-- form start -->
                        <form class="form-horizontal form-submit-event"
                            action="<?= base_url('admin/Notification_settings/send_notifications'); ?>" method="POST"
                            id="add_product_form" enctype="multipart/form-data">
                            <?php
                            $curr_time = date('y-m-d H:i:s'); ?>
                            <input type="hidden" id="start_date" name="start_time"
                                value="<?= isset($flash_sales[0]['start_date']) ? $flash_sales[0]['start_date'] : ''; ?>">
                            <input type="hidden" id="end_date" name="end_time"
                                value="<?= isset($flash_sales[0]['end_date']) ? $flash_sales[0]['end_date'] : ''; ?>">
                            <input type="hidden" id="server_time" name="server_time" value="<?= $curr_time ?>">
                            <?php
                            if (isset($fetched_data) && !empty($fetched_data) && isset($fetched_data[0]['id'])) {
                                ?>
                                <input type="hidden" id="edit_area" name="edit_notification"
                                    value="<?= @$fetched_data[0]['id'] ?>">
                                <input type="hidden" id="update_id" name="update_id" value="1">
                            <?php } ?>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="type" class="control-label mt-2">Send to <span
                                            class='text-danger text-sm'>*</span></label>
                                    <select name="send_to" id="send_to" class="form-control type_event_trigger mt-2"
                                        required="">
                                        <option value="all_users">All Users</option>
                                        <option value="specific_user">Specific User</option>
                                    </select>
                                </div>

                                <!-- for users -->
                                <?php $hiddenStatus = (isset($fetched_data[0]['id']) && $fetched_data[0]['type'] == 'users') ? '' : 'd-none' ?>
                                <div class="form-group row notification-users <?= $hiddenStatus ?>">
                                    <label for="user_id" class="control-label mt-2"> Users <span
                                            class='text-danger text-sm'>*</span></label>
                                    <div class="col-md-12 mt-2">
                                        <input type="hidden" name="user_id" id="noti_user_id" value="">
                                        <select name="select_user_id[]" class="search_user w-100" multiple
                                            data-placeholder=" Type to search and select users" onload="multiselect()">
                                            <?php
                                            if (isset($fetched_data[0]['id']) && $fetched_data[0]['type'] == 'users') {
                                                $user_details = fetch_details('users', ['id' => $row['type_id']], 'id,name');

                                                if (!empty($user_details)) {
                                                    ?>
                                                    <option value="<?= $user_details[0]['id'] ?>" selected>
                                                        <?= $user_details[0]['name']; ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="type" class="control-label mt-2">Type <span
                                            class='text-danger text-sm'>*</span></label>
                                    <div class="col-md-12 mt-2">
                                        <select name="type" id="type" class="form-control type_event_trigger"
                                            required="">
                                            <option value=" ">Select Type</option>
                                            <option value="default" <?= (@$fetched_data[0]['type'] == "default") ? 'selected' : ' ' ?>>Default</option>
                                            <option value="categories" <?= (@$fetched_data[0]['type'] == "categories") ? 'selected' : ' ' ?>>Category</option>
                                            <option value="products" <?= (@$fetched_data[0]['type'] == "products") ? 'selected' : ' ' ?>>Product</option>
                                            <option value="flash_sale" <?= (@$fetched_data[0]['type'] == "flash_sale") ? 'selected' : ' ' ?>>Flash Sale</option>
                                            <option value="notification_url"
                                                <?= (@$fetched_data[0]['type'] == "notification_url") ? 'selected' : ' ' ?>>Notification URL</option>
                                        </select>
                                    </div>
                                </div>
                                <div id="type_add_html">
                                    <?php $hiddenStatus = (isset($fetched_data[0]['id']) && $fetched_data[0]['type'] == 'categories') ? '' : 'd-none' ?>

                                    <div class="form-group notification-categories <?= $hiddenStatus ?>">
                                        <label for="category_id">Categories <span
                                                class='text-danger text-sm'>*</span></label>
                                        <select name="category_id" id="category_id" class="form-control select2"
                                            style="width: 100%;">
                                            <option value="">Select category</option>
                                            <?php
                                            if (!empty($categories)) {
                                                foreach ($categories as $row) {
                                                    $selected = ($row['id'] == $fetched_data[0]['type_id'] && strtolower($fetched_data[0]['type']) == 'categories') ? 'selected' : '';
                                            ?>
                                                    <option value="<?= $row['id'] ?>" <?= $selected ?>> <?= $row['name'] ?></option>
                                            <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <?php $hiddenStatus = (isset($fetched_data[0]['id']) && $fetched_data[0]['type'] == 'notification_url') ? '' : 'd-none' ?>
                                    <div class="form-group notification-url <?= $hiddenStatus ?> ">

                                        <label for="notification_url" class="mt-2"> Link <span
                                                class='text-danger text-sm'>*</span></label>
                                        <input type="url" class="form-control mt-2" placeholder="https://example.com"
                                            name="link" id="link"
                                            value="<?= isset($fetched_data[0]['link']) ? output_escaping($fetched_data[0]['link']) : "" ?>"
                                            pattern="https?://.+"
                                            title="Please enter a valid URL starting with http:// or https://">
                                        <small class="form-text text-muted">URL must start with http:// or
                                            https://</small>
                                    </div>
                                    <?php $hiddenStatus = (isset($fetched_data[0]['id']) && $fetched_data[0]['type'] == 'products') ? '' : 'd-none' ?>

                                    <div class="form-group row notification-products <?= $hiddenStatus ?>">
                                        <label for="product_id" class="control-label">Products <span
                                                class='text-danger text-sm'>*</span></label>
                                        <div class="col-md-12">
                                            <select name="product_id" class="search_product w-100"
                                                data-placeholder=" Type to search and select products"
                                                onload="multiselect()">
                                                <?php
                                                if (isset($fetched_data[0]['id']) && $fetched_data[0]['type'] == 'products') {
                                                    $product_details = fetch_details('products', ['id' => $row['type_id']], 'id,name');
                                                    if (!empty($product_details)) {
                                                        ?>
                                                        <option value="<?= $product_details[0]['id'] ?>" selected>
                                                            <?= $product_details[0]['name'] ?></option>
                                                        <?php
                                                    }
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <?php $hiddenStatus = (isset($fetched_data[0]['id']) && $fetched_data[0]['type'] == 'flash_sale') ? '' : 'd-none' ?>

                                    <div class="form-group row notification-flash-sale <?= $hiddenStatus ?>">
                                        <label for="sale_id" class="control-label">Flash sale <span
                                                class='text-danger text-sm'>*</span></label>
                                        <div class="col-md-12">
                                            <select name="sale_id" class="form-control">
                                                <option value="">Select flash sale </option>
                                                <?php
                                                if (!empty($flash_sales)) {
                                                    foreach ($flash_sales as $flash_sale) {
                                                        $selected = ($flash_sale['id'] == $fetched_data[0]['type_id'] && strtolower($fetched_data[0]['type']) == 'flash_sale') ? 'selected' : '';
                                                ?>
                                                        <option value="<?= $flash_sale['id'] ?>" <?= $selected ?>> <?= $flash_sale['title'] ?></option>
                                                <?php
                                                    }
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="title" class="control-label mt-2">Title <span
                                            class='text-danger text-sm'>*</span></label>
                                    <div class="col-md-12">
                                        <input type="text" class="form-control mt-2" name="title" id="title"
                                            value="<?= (isset($fetched_data[0]['title']) ? $fetched_data[0]['title'] : '') ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="message" class="control-label mt-2">Message <span
                                            class='text-danger text-sm'>*</span></label>
                                    <div class="col-md-12 mt-2">
                                        <textarea name='message' class="form-control"></textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-12 mt-2">
                                        <input type="checkbox" name="image_checkbox" id="image_checkbox">
                                        <span>Include Image</span>
                                    </div>
                                    <div class="col-md-12 d-none include_image">
                                        <label for="message" class="control-label">Image <small>(Recommended Size : 80 x
                                                80 pixels)</small></label>
                                        <div class="col-sm-10">
                                            <div class='col-md-3'><a
                                                    class="uploadFile img btn btn-primary text-white btn-sm"
                                                    data-input='image' data-isremovable='1'
                                                    data-is-multiple-uploads-allowed='0' data-toggle="modal"
                                                    data-target="#media-upload-modal" value="Upload Photo"><i
                                                        class='fa fa-upload'></i> Upload</a></div>
                                            <?php
                                            if (file_exists(FCPATH . @$fetched_data[0]['image']) && !empty(@$fetched_data[0]['image'])) {
                                            ?>
                                                <div class="container-fluid row image-upload-section">
                                                    <div
                                                        class="col-md-3 col-sm-12 shadow p-3 mb-5 bg-white rounded m-4 text-center grow image">
                                                        <div class='image-upload-div'><img class="img-fluid mb-2"
                                                                src="<?= BASE_URL() . $fetched_data[0]['image'] ?>"
                                                                alt="Image Not Found"></div>
                                                        <input type="hidden" name="image"
                                                            value='<?= $fetched_data[0]['image'] ?>'>
                                                    </div>
                                                </div>
                                                <?php
                                            } else { ?>
                                                <div class="container-fluid row image-upload-section">
                                                    <div
                                                        class="col-md-3 col-sm-12 shadow p-3 mb-5 bg-white rounded m-4 text-center grow image d-none">
                                                    </div>
                                                </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group mt-3">
                                    <button type="reset" class="btn btn-warning">Reset</button>
                                    <button type="submit" class="btn btn-success" id="submit_btn">Send
                                        Notification</button>
                                </div>
                        </form>
                    </div>
                    <!--/.card-->
                </div>
                <div class="col-md-12 main-content mt-4">
                    <div class="card content-area p-4">
                        <div class="col-sm-2">
                            <label for="send_notification_type_filter" class="col-form-label fs-6">Filter Send
                                Notification By Type </label>
                            <select id="send_notification_type_filter" name="send_notification_type_filter"
                                placeholder="Select Status" required="" class="form-control">
                                <option value="">All</option>
                                <option value="default">Default</option>
                                <option value="categories">Category</option>
                                <option value="products">Products</option>
                                <option value="flash_sale">Flash Sale</option>
                                <option value="notification_url">Notification Url</option>
                            </select>
                        </div>
                        <div class="card-innr">
                            <div class="gaps-1-5x"></div>
                            <table class='table-striped' data-toggle="table"
                                data-url="<?= base_url('admin/Notification_settings/get_notification_list') ?>"
                                data-click-to-select="true" data-side-pagination="server" data-pagination="true"
                                data-page-list="[5, 10, 20, 50, 100, 200]" data-search="true" data-show-columns="true"
                                data-show-refresh="true" data-trim-on-search="false" data-sort-name="id"
                                data-sort-order="desc" data-mobile-responsive="true" data-toolbar=""
                                data-show-export="true" data-maintain-selected="true"
                                data-export-types='["txt","excel"]' data-query-params="SendNotificationQueryParams">
                                <thead>
                                    <tr>
                                        <th data-field="id" data-sortable="true">ID</th>
                                        <th data-field="users_id" data-sortable="false">users id</th>
                                        <th data-field="title" data-sortable="false">Title</th>
                                        <th data-field="type" data-sortable="false">Type</th>
                                        <th data-field="image" data-sortable="false" class="col-md-5">Image</th>
                                        <th data-field="link" data-sortable="false" class="col-md-5">Link</th>
                                        <th data-field="message" data-sortable="false">Message</th>
                                        <th data-field="send_to" data-sortable="false">Send to</th>
                                        <th data-field="operate" data-sortable="false">Actions</th>
                                    </tr>
                                </thead>
                            </table>
                        </div><!-- .card-innr -->
                    </div><!-- .card -->
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>